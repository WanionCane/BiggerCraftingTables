Thank you for reporting!

For issues:
 * If the issue seems to affect only one mod, report to them instead of here.
 * Remove NEI and FEI to see if they are causing the issue before reporting.
 * If you crashed, please paste the crash log to [gist](https://gist.github.com/) and link it here.

For suggestions:
 * Please do not suggest features from NEI. [See this spreadsheet](https://goo.gl/MQ0f3R) before requesting.
