package mezz.jei.config;

public enum IngredientBlacklistType {
	ITEM, WILDCARD, MOD_ID;

	public static final IngredientBlacklistType[] VALUES = values();
}
