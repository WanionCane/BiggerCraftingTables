package mezz.jei.gui.ghost;

import mezz.jei.gui.ingredients.IIngredientListElement;

public interface IGhostIngredientDragSource {
	IIngredientListElement getElementUnderMouse();
}
